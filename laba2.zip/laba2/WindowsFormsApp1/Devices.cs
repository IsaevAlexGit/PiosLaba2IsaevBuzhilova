﻿using System.Drawing;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    // Класс «Devices» содержит логику управления внешними устройствами.
    public class Devices
    {
        // Структура для удобства работы с каждым датчиком
        public struct Radio
        {
            // Переключатели вкл, выкл и цвет внешнего устройства
            public RadioButton rb1;
            public RadioButton rb2;
            public Color color;

            public Radio(RadioButton r1, RadioButton r2, Color c)
            {
                rb1 = r1;
                rb2 = r2;
                color = c;
            }
        }

        // Управление вентиляцией кухни
        public Radio manageKitchenVentilation(Data data, RadioButton radioButton1, RadioButton radioButton2, Panel panelTemp)
        {
            // Если температура выше 35, то включить вентиляцию на кухне
            if (data.valueWithTemperature >= data.getLimitTemperature())
            {
                radioButton1.Checked = true;
                panelTemp.BackColor = Color.Yellow;
            }
            else
            {
                radioButton2.Checked = true;
                panelTemp.BackColor = Color.Black;
            }
            return new Radio(radioButton1, radioButton2, panelTemp.BackColor);
        }

        // Управление вентиляцией душа
        public Radio manageShowerVentilation(Data data, RadioButton radioButton3, RadioButton radioButton4, Panel panelVlaga)
        {
            // Если влажность выше 66, то включать вентиляцию в душевой
            if (data.valueWithVlaga <= data.getLimitVlaga())
            {
                radioButton3.Checked = true;
                panelVlaga.BackColor = Color.Black;
            }
            else
            {
                radioButton4.Checked = true;
                panelVlaga.BackColor = Color.Yellow;
            }
            return new Radio(radioButton3, radioButton4, panelVlaga.BackColor);
        }

        // Управление светом около двери
        public Radio manageLightingNearTheDoor(Data data, RadioButton radioButton5, RadioButton radioButton6, Panel panelLight)
        {
            // Если освещенность ниже 30, то включать освещение возле входной двери
            if (data.valueWithLight < data.getLimitLight())
            {
                radioButton5.Checked = true;
                panelLight.BackColor = Color.Yellow;
            }
            else
            {
                radioButton6.Checked = true;
                panelLight.BackColor = Color.Black;
            }
            return new Radio(radioButton5, radioButton6, panelLight.BackColor);
        }
    }
}