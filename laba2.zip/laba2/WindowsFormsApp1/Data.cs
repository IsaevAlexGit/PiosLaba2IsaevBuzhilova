﻿namespace WindowsFormsApp1
{
    // Класс «Data» хранит настройки и показания датчиков.
    public class Data
    {
        // Пороговые значения - настройки
        private int limitTemperature = 35;
        private int limitVlaga = 65;
        private int limitLight = 30;

        // Показания датчиков
        public int valueWithTemperature;
        public int valueWithVlaga;
        public int valueWithLight;
        public int valueWithAtmDavlenie;

        // Геттеры настроек
        public int getLimitTemperature()
        {
            return limitTemperature;
        }
        public int getLimitVlaga()
        {
            return limitVlaga;
        }
        public int getLimitLight()
        {
            return limitLight;
        }

        // Сеттеры настроек
        public void setLimitTemperature(int _temp)
        {
            limitTemperature = _temp;
        }
        public void setLimitVlaga(int _vlaga)
        {
            limitVlaga = _vlaga;
        }
        public void setLimitLight(int _light)
        {
            limitLight = _light;
        }
    }
}