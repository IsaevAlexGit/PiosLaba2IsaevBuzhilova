﻿using System;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    // Класс «Sensors» опрашивает датчики и преобразовывает полученные данные.
    public class Sensors : Form
    {
        // Закрытые поля - значения, считанные с датчиков
        private int valueFromTextBoxTemperature;
        private int valueFromTextBoxVlaga;
        private int valueFromTextBoxLight;
        private int valueFromTextBoxAtm;
        public void pollSensors(NumericUpDown t, NumericUpDown v, NumericUpDown l, NumericUpDown a)
        {
            // Получить текущие параметры с датчиков
            valueFromTextBoxTemperature = Convert.ToInt32(t.Value);
            valueFromTextBoxVlaga = Convert.ToInt32(v.Value);
            valueFromTextBoxLight = Convert.ToInt32(l.Value);
            valueFromTextBoxAtm = Convert.ToInt32(a.Value);
        }

        // Геттеры закрытых полей
        public int getTemperature()
        {
            return valueFromTextBoxTemperature;
        }
        public int getVlaga()
        {
            return valueFromTextBoxVlaga;
        }
        public int getLight()
        {
            return valueFromTextBoxLight;
        }
        public int getAtm()
        {
            return valueFromTextBoxAtm;
        }
    }
}