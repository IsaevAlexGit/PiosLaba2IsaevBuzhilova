﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp1
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        // Отрисовка границ groupbox
        private PaintBorder _paintGroupBoxBorder = new PaintBorder();
        // Счетчик секунд для обновления графиков
        private int _countSeconds = 0;
        // Объект с настройками и считанными значениями
        private Data data = new Data();
        // Объект для получения данных с датчиков
        private Sensors sensors = new Sensors();
        // Объект для управления внешними устройствами
        private Devices devices = new Devices();

        // Загрузка формы
        private void Form1_Load(object sender, EventArgs e)
        {
            // Отобразить стартовые пороговые значения
            textBoxTemperature.Text = data.getLimitTemperature().ToString();
            textBoxVlaga.Text = data.getLimitVlaga().ToString();
            textBoxLight.Text = data.getLimitLight().ToString();

            // Старт таймера
            timer.Enabled = true;

            // Отрисовка границ groupbox
            foreach (Control groupbox in Controls)
            {
                GroupBox everyGroupBox = groupbox as GroupBox;
                if (everyGroupBox != null)
                    everyGroupBox.Paint += _paintGroupBoxBorder.groupBox_Paint;
            }

            // Настройка температуры
            panelTemp.BackColor = Color.Black;
            // Максимальная и минимальная температура
            numericTemperature.Maximum = 40;
            numericTemperature.Minimum = 0;
            // Ось Y - от -5 до 45 градусов
            chartTemp.ChartAreas[0].AxisY.Maximum = 45;
            chartTemp.ChartAreas[0].AxisY.Minimum = -5;
            // Формат ячеек по оси Х
            chartTemp.ChartAreas[0].AxisX.LabelStyle.Format = "H:mm:ss";
            chartTemp.Series[0].XValueType = ChartValueType.DateTime;
            // Минимум оси Х
            chartTemp.ChartAreas[0].AxisX.Minimum = DateTime.Now.ToOADate();
            // Максимум оси Х
            chartTemp.ChartAreas[0].AxisX.Maximum = DateTime.Now.AddMinutes(1).ToOADate();
            // Интервал времен на оси Х 
            chartTemp.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Seconds;
            chartTemp.ChartAreas[0].AxisX.Interval = 5;

            // Настройка влажности
            panelVlaga.BackColor = Color.Black;
            // Максимальная и минимальная влажность
            numericVlaga.Maximum = 80;
            numericVlaga.Minimum = 60;
            // Ось Y - от 55 до 85 влажности
            chartVlaga.ChartAreas[0].AxisY.Maximum = 85;
            chartVlaga.ChartAreas[0].AxisY.Minimum = 55;
            // Формат ячеек по оси Х
            chartVlaga.ChartAreas[0].AxisX.LabelStyle.Format = "H:mm:ss";
            chartVlaga.Series[0].XValueType = ChartValueType.DateTime;
            // Минимум оси Х
            chartVlaga.ChartAreas[0].AxisX.Minimum = DateTime.Now.ToOADate();
            // Максимум оси Х
            chartVlaga.ChartAreas[0].AxisX.Maximum = DateTime.Now.AddMinutes(1).ToOADate();
            // Интервал времен на оси Х 
            chartVlaga.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Seconds;
            chartVlaga.ChartAreas[0].AxisX.Interval = 5;

            panelLight.BackColor = Color.Black;
            // Максимальная и минимальная освещенность
            numericLight.Maximum = 35;
            numericLight.Minimum = 22;
            // Ось Y - от 21 до 36 люксов
            chartLight.ChartAreas[0].AxisY.Maximum = 36;
            chartLight.ChartAreas[0].AxisY.Minimum = 21;
            // Формат ячеек по оси Х
            chartLight.ChartAreas[0].AxisX.LabelStyle.Format = "H:mm:ss";
            chartLight.Series[0].XValueType = ChartValueType.DateTime;
            // Минимум оси Х
            chartLight.ChartAreas[0].AxisX.Minimum = DateTime.Now.ToOADate();
            // Максимум оси Х
            chartLight.ChartAreas[0].AxisX.Maximum = DateTime.Now.AddMinutes(1).ToOADate();
            // Интервал времен на оси Х 
            chartLight.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Seconds;
            chartLight.ChartAreas[0].AxisX.Interval = 5;

            // Максимальное и минимальное атм.давление
            numericAtm.Maximum = 765;
            numericAtm.Minimum = 760;
            // Ось Y - от 759 до 766 давления
            chartAtm.ChartAreas[0].AxisY.Maximum = 766;
            chartAtm.ChartAreas[0].AxisY.Minimum = 759;
            // Формат ячеек по оси Х
            chartAtm.ChartAreas[0].AxisX.LabelStyle.Format = "H:mm:ss";
            chartAtm.Series[0].XValueType = ChartValueType.DateTime;
            // Минимум оси Х
            chartAtm.ChartAreas[0].AxisX.Minimum = DateTime.Now.ToOADate();
            // Максимум оси Х
            chartAtm.ChartAreas[0].AxisX.Maximum = DateTime.Now.AddMinutes(1).ToOADate();
            // Интервал времен на оси Х 
            chartAtm.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Seconds;
            chartAtm.ChartAreas[0].AxisX.Interval = 5;
        }

        // Управление датчиками при известных данных - работа таймера
        private void manageDevices(object sender, EventArgs e)
        {
            // Получить текущее время
            DateTime timeNow = DateTime.Now;

            // Опросить датчики и узнать значения на них
            sensors.pollSensors(numericTemperature, numericVlaga, numericLight, numericAtm);

            // Сохранить данные из датчиков в Data
            _SaveValues();

            // Отрисовка всех 4 графиков
            chartTemp.Series[0].Points.AddXY(timeNow, data.valueWithTemperature);
            chartVlaga.Series[0].Points.AddXY(timeNow, data.valueWithVlaga);
            chartLight.Series[0].Points.AddXY(timeNow, data.valueWithLight);
            chartAtm.Series[0].Points.AddXY(timeNow, data.valueWithAtmDavlenie);

            // Узнав настройки, значения с датчиков вызывываем управления внешними устройствами
            radioButton1 = devices.manageKitchenVentilation(data, radioButton1, radioButton2, panelTemp).rb1;
            radioButton2 = devices.manageKitchenVentilation(data, radioButton1, radioButton2, panelTemp).rb2;
            panelTemp.BackColor = devices.manageKitchenVentilation(data, radioButton1, radioButton2, panelTemp).color;

            radioButton3 = devices.manageShowerVentilation(data, radioButton3, radioButton4, panelVlaga).rb1;
            radioButton4 = devices.manageShowerVentilation(data, radioButton3, radioButton4, panelVlaga).rb2;
            panelVlaga.BackColor = devices.manageShowerVentilation(data, radioButton3, radioButton4, panelVlaga).color;

            radioButton5 = devices.manageLightingNearTheDoor(data, radioButton5, radioButton6, panelLight).rb1;
            radioButton6 = devices.manageLightingNearTheDoor(data, radioButton5, radioButton6, panelLight).rb2;
            panelLight.BackColor = devices.manageLightingNearTheDoor(data, radioButton5, radioButton6, panelLight).color;

            // Нарастить счетчик секунд
            _countSeconds++;

            // Если прошла 1 минута, то нужно обновит графики
            if (_countSeconds == 60)
            {
                // Сбросить таймер
                _countSeconds = 0;

                // Перерисовка всех диаграмм каждые 5 минут
                _RefrechChart(chartTemp);
                _RefrechChart(chartVlaga);
                _RefrechChart(chartLight);
                _RefrechChart(chartAtm);
            }
        }

        // По истечении минуты перерисовать все диаграммы
        private void _RefrechChart(Chart chart)
        {
            // Перестроить все оси Х, начиная с новой минуты
            chart.ChartAreas[0].AxisX.Minimum = DateTime.Now.ToOADate();
            chart.ChartAreas[0].AxisX.Maximum = DateTime.Now.AddMinutes(1).ToOADate();
            chart.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Seconds;
            chart.ChartAreas[0].AxisX.Interval = 5;
        }

        // Сохранить данные из датчиков в Data
        private void _SaveValues()
        {
            // Полученные из запроса к датчикам данные - заносим в класс Data
            data.valueWithTemperature = sensors.getTemperature();
            data.valueWithVlaga = sensors.getVlaga();
            data.valueWithLight = sensors.getLight();
            data.valueWithAtmDavlenie = sensors.getAtm();
        }

        // Установить параметры пороговых значений
        private void buttonSetupParam_Click(object sender, EventArgs e)
        {
            int tempValue;
            bool trueint1 = int.TryParse(textBoxTemperature.Text, out tempValue);
            bool trueint2 = int.TryParse(textBoxVlaga.Text, out tempValue);
            bool trueint3 = int.TryParse(textBoxLight.Text, out tempValue);
            // Если везде ввели числа
            if (trueint1 && trueint2 && trueint3)
            {
                int param1 = Convert.ToInt32(textBoxTemperature.Text);
                int param2 = Convert.ToInt32(textBoxVlaga.Text);
                int param3 = Convert.ToInt32(textBoxLight.Text);
                // Сохранить пороговые настройки в Data
                _SaveSettings(param1, param2, param3);
            }
            else
                MessageBox.Show("Введены не числа", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Сохранить введенные настройки в класс Data
        private void _SaveSettings(int p1, int p2, int p3)
        {
            // Если числа в нужно интервале
            if (p1 >= 0 && p1 <= 40)
                data.setLimitTemperature(Convert.ToInt32(textBoxTemperature.Text));
            if (p2 >= 60 && p2 <= 80)
                data.setLimitVlaga(Convert.ToInt32(textBoxVlaga.Text));
            if (p3 >= 22 && p3 <= 35)
                data.setLimitLight(Convert.ToInt32(textBoxLight.Text));
        }
    }
}